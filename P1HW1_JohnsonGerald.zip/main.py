num1 = int(input())
num2 = int(input())
num3 = num1 + num2
num4 = num1 * num2
print(num1)
print(num2)
print(num3)
print(num4)