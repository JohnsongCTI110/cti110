#This code is meant to create and modify a list of 7 scores, and to find the average score of the adjusted score list.
#CTI-110
#P2HW2-Score Avg
#Gerald Johnson
#5/10/2022
#
###########################Pseudo-Code##################################
#Display "Enter score #1: "
#Input score_1
#Display "Enter score #2: "
#Input score_2
#Display "Enter score #3: "
#Input score_3
#Display "Enter score #4: "
#Input score_4
#Display "Enter score #5: "
#Input score_5
#Display "Enter score #6: "
#Input score_6
#Display "Enter score #7: "
#Input score_7
#Set Scores = [score_1, score_2, score_3, score_4, score_5, score_6, score_7]
#Set lowest_score = min(Scores)
#Display "--------------Results--------------"
#Display "Lowest Score  :  {}".format(lowest_score)
#Set modified_list = [score_1, score_2, score_3, score_4, score_5, score_6, score_7]
#Set modified_list.remove(score_4)
#Display "Modified List : ",(modified_list)
#Set score_avg = sum(modified_list) / 6
#Display "Score Average: ", format(score_avg, ".2f")
#Display "-----------------------------------"
#
#Create seprate float input statements for the 7 scores.
score_1 = float(input('Enter score #1: '))
score_2 = float(input('Enter score #2: '))
score_3 = float(input('Enter score #3: '))
score_4 = float(input('Enter score #4: '))
score_5 = float(input('Enter score #5: '))
score_6 = float(input('Enter score #6: '))
score_7 = float(input('Enter score #7: '))
#Create a list for the Scores.
Scores = [score_1, score_2, score_3, score_4, score_5, score_6, score_7]
#create a variable for lowest_score, and add a min operation, to find the lowest score in the Scores list.
lowest_score = min(Scores)
#dashline Results print statement.
print('\n--------------Results---------------')
#create a print statement that allows the code to find the lowest score in the list.
print('Lowest Score  :  {}'.format(lowest_score))
#Create a new list that will allow you to modify the list.
modified_list = [score_1, score_2, score_3, score_4, score_5, score_6, score_7]
#Create a remove statement to remove a score from the list.
modified_list.remove(score_4)
#create print statement that allows you to see the new modified list.
print('Modified List : ',(modified_list))
#Create a variable to calculate and find the average score total of the scores list.
score_avg = sum(modified_list) / 6
#print statement the allows code to calculate the average of all the remaining scores in the list. 
print('Scores Average: ', format(score_avg, '.2f'))
#Closing dashline print statement.
print('--------------------------------------')
